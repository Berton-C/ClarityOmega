# Corner-Gate v3 Draft A.1: Payload Identity Manifest

**Date:** 2026-07-09
**Status:** DRAFT A.1 DELIVERED FOR BERTON RATIFICATION. Nothing installed. Draft B verifies these hashes before applying. Hashes refresh on any further revision.
**Design canon:** corner_gate_v3_adapter_design.md (amendment lines for the canon copy listed at the end).

## Payload hashes (sha256)

```
18ab6d533b0595f1d8158765b2ccfed51b75b4951784088a6c3cba4f624a0489  coupling_legibility.metta
8e2ed0e7b268d1ed7af8c29c46d7d54762537eb27701cf9f0568cf14d0fd0845  coupling_legibility_writers.metta
6303d85c75447dca34e578c556411103841490ff13c3476df97d14446ba1e731  coupling_legibility_helper_payload.py
```

## Expected target paths, import positions, loop swap sites

Unchanged from Draft A: CREATE soul/coupling_legibility.metta and soul/coupling_legibility_writers.metta; PATCH src/helper.py (append payload 3); both imports AFTER the engine (line 14) and after the corner_gap block (line 103), pure first, writers second; loop swaps at ~166 (apply-corner-gate-v2 rebody to pass-through), ~168 (gate-aware-results rebody to line appender via coupling-legibility-line), tail hook REPLACE populate-corner-window! with ($_ (do-record-coupling-cycle! $metta_cmds $msgnew $k (get-state &error))), initLoop gains ($_ (do-bootstrap-coupling!)).

## Blocker resolutions (B1-B5, all resolved)

- **B1 trace verdict wired.** Pure file adds (coupling-trace-verdict-for-window) and (latest-coupling-trace-verdict): reads the window's three stored polarity verdicts by ordinal order (min, mid, max) and calls (q-tfs2-trace-verdict? same-start $v2 $v3). The composer's trajectory field uses the trace verdict when the window is full, window-filling before then. Ratification conditions carried to Draft B harness: PC1 must produce blocked-repetition-without-metabolization; PC2 must not.
- **B2 contact-count is surface-count.** do-record-contact-event! is remove-specific-then-add (idempotent per ord and surface), and coupling-contact-surfaces dedupes defensively. New fixture carried to Draft B: batch query plus metta yields contact-count 1, dominant runtime-output.
- **B3 hidden failures increment.** Recorder reads $delta FIRST; failed = visible-error OR (sig not none AND delta none). Pin-only and empty batches sign as none and never count as failures. Ratification condition carried to Draft B: PC1 proves repeated same-signature, no-forward, no-visible-feedback increments the fail count and reaches the intended trace verdict.
- **B4 totalized classification.** (surface-for-head-total) and (command-class-of-total) branch on the explicit known-heads list with fallbacks no-contact and neutral; writers call only the total forms. Fixture carried to Draft B: unknown head yields no-contact, neutral, zero unreduced fields.
- **B5 MeTTa line composer exists.** (coupling-legibility-line): reads only through field helpers, sequences every binding, py-calls the formatter with ten flat values, never touches the record tuple, renders the window-filling line on an empty window. Fixture carried to Draft B: live reduction to a COUPLING-STATE string with no tuple render and no unreduced variables.

## Amendment resolutions

- A1 bootstrap NORMALIZES: remove-all then add for both singletons, exactly one of each from any prior state.
- A3 / RF3 answered: remember is NEUTRAL class in v1. Rationale: its target (the memory string) has no mechanically verifiable durable target, so action-class status would create Gate H inconsistency. Its executed surface remains runtime-output.
- Helper 1: H4 verified in this delivery (different-target hash can never equal the action target; see verification below). H4 fixture also carried to Draft B.
- Helper 2: sha256[:8] replaces md5, documented as compact non-security identity hash.
- Helper 3 / RF13 resolved: pin-only and empty batches sign as none, no hash. Rationale: pins are narration; narration must not become command lineage; pin loops are caught by the no-contact path (NC1, symbolic-capture), not signature repetition.
- Helper 4: shell EXCLUDED from target extraction; shell actions yield unknown, honesty not-computed. Conservative both ways: no false claim-completion, no false accusation. Comment corrected.
- Helper 5: head regex widened to letters, digits, underscores, hyphens, and trailing ! or ?.
- Pure 1 and 2: latest-coupling-context and latest-coupling-lineage exist under the ratified names, returning the primary component (ctx-phase, producer), with component helpers beside them.
- RF12 wording adopted: ctx-soul is a surface-presence context marker, not approval status.

## Verification run on this delivery

Paren delta 0 on both MeTTa files. Helper live tests: H1 basis (same path, action and verification targets identical), H4 basis (different path never equal), H3 basis (shell action yields unknown), pin-only and empty signatures return none, digit-bearing head parses, corner-region line renders with honesty shown, healthy line renders with claim-completion hidden, all-None input renders the safe not-computed line.

## Open rulings for Berton (the A.1 ratification set)

- **RF8-PENDING, next-move mapping ACTIVE in the payload.** Every output symbol is verbatim engine move vocabulary with engine line citations in the pure file (block-reinforcement-and-seek-contact 1226, preserve-learning-trace 2169, prevent-self-certification 2174, make-trajectory-legible 2176, integrate-outcome 2179, continue-inquiry 2166). The STATE-to-move pairing is adapter-side and is what you are ratifying. Precedence: honesty outranks trace verdict outranks chain state. Rejection reverts derive-next-move to not-computed in one line. Note: your proposed inspect-process-trace is engine vocabulary (3143) but is the move for process-embedded; the mapping above uses closer-fit engine moves. seek-harness-evidence and preserve-course are not engine symbols and were not used.
- **RF11-RES, contact accord storage.** The doc's 2.6 derivations are followed: both accords are computed per cycle (contact navigation leg is mechanical: with a live repetition, alignment requires the corrective probe; otherwise aligned). The ratified 17-field record stores the TASK accord in $accord-summary. Ruling needed: keep contact accord computed-only in v1 (current payload), or add an 18th field and a line slot (schema version would bump to v3-18-field).
- **RF4 final v1 contact-surface mapping** as now implemented (table in the writers file): confirm or amend.

## Design doc amendment lines for the canon copy (accepted items)

1. Section 3.2 and 3.5: replace "exact-old-value set-atom! replace" with "remove-by-variable then add (Atom Operations Map N1 writer doctrine; CONTRA-setatom safety correction)". Bootstrap normalizes rather than guards.
2. Section 5.5 Draft A item 3: "helper.coupling_line_format payload" becomes "helper payload: line formatter plus command-signature and action/verification target extraction (hands-only string plumbing; compact non-security sha256 identity hashes)".
3. Section 2.5 Gate H: add "Claim-present is a v1 proxy: a claim-class (send) command in the cycle; content is never read. name-action-not-verification can therefore appear only when action and send co-occur."
4. Section 3.1 $ctx-soul: add "a surface-presence context marker, not approval status".
5. Section 4 render: add "the trajectory field carries the window trace verdict when the window is full, window-filling before then".
6. Section 7 D9: note shell actions yield target unknown (honesty not-computed) in v1.
7. If RF8 is ratified: Section 4 and 7 note the next-move mapping as adapter-side pairing over verbatim engine move vocabulary, with the precedence rule. If rejected: Section 4 notes next renders not-computed in v1.

Manifest end.
