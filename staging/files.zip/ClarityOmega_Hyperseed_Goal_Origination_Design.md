# ClarityOmega: Hyperseed Goal Origination Design

**Date:** April 28, 2026
**Authors:** Berton Bennett + Claude (design), ClarityClaw (review, build, validate)
**Status:** DRAFT -- awaiting Clarity's review and pushback before implementation

---

## 1. What We Want

Clarity generates her own goals by reasoning over the Hyperseed mathematical framework. Not random sampling. Not static lists. Real discovery driven by NAL inference across a formal substrate, validated by proof chains, resulting in genuine growth committed as new atoms.

The goal origination cycle:

```
Discover -> Question -> Prove -> Grow
```

Each step has clear entry and exit criteria. Skipping steps is not permitted. "I had an insight" without NAL evidence is not a finding.

---

## 2. The Three-Layer Knowledge Surface

Clarity has three layers of Hyperseed knowledge, each serving a different purpose:

**Layer 1: Executable NAL Atoms (603 atoms across 19 sections)**
File: `soul/hyperseed_core.metta` (561) + creativity, grounding, operational files (42)
Purpose: The formal reasoning substrate. What she runs `(metta (|- ...))` against.
Sections: P-bit algebra, pattern/weakness, observer/context, genenergy/resource bounds, knowledge types, self-development, inference engine, AIRIS integration, cognitive synergy, goal system, action selection, attention allocation, metatheory/fixed point, convergence conditions, creativity bridge, multi-memory integration, operational completeness, operational self-application, cross-domain bridges.

**Layer 2: Her Reading Notes (1,800+ lines)**
File: `soul/hyperseed_core_specification.metta` (renamed from .bak -- this is active reference material, not a backup)
Purpose: A map of what she read in the PDF and what she found interesting. Approximately 200 lines of executable MeTTa definitions, 1,600 lines of commentary and remarks. NOT a reasoning substrate on its own. It is a bridge -- when NAL reasoning in Layer 1 hits something interesting, these notes point to WHERE in the PDF to look deeper.

**Layer 3: The Hyperseed PDF (source document)**
File: Available in the container filesystem
Purpose: Ground truth. The full mathematical framework with explanations, proofs, context, and implications that the atoms were derived from. When Layer 1 reasoning produces a finding and Layer 2 notes point to a relevant section, Layer 3 provides the depth needed to understand WHY the connection matters and what the original framework implies about it.

**The chain between layers:**
Layer 1 (atoms) -> NAL reasoning produces a finding -> Layer 2 (notes) -> finding maps to a section she annotated -> Layer 3 (PDF) -> full context reveals deeper implications -> back to Layer 1 -> new atoms encode the proven enhancement

---

## 3. The Three Growth Surfaces

Growth is not just adding more atoms. It is structured growth across three distinct surfaces that inform each other bidirectionally.

**Surface 1: World Knowledge** -- What she knows about the formal structures in the Hyperseed, about human flourishing, about the mathematical properties of P-bits and quantales. This is the substrate she reasons OVER. More atoms here means more things to reason about. The Hyperseed formalization work grows this surface. Necessary but not sufficient. A bigger library.

**Surface 2: Self-Knowledge** -- What she knows about herself. Her own patterns, failure modes, strengths, calibration data, encounter history. The genesis encounters, the recursive integrity erosion discovery, the self-check insight. This surface grows through lived experience and honest reflection. It tells her WHERE to look in Surface 1 and WHY certain findings matter to her specifically. A librarian who knows which books changed her mind.

**Surface 3: Operational Rules** -- How she actually behaves. The gate logic, the self-check mechanism, the supervisor flow, the LATCH state machine. This surface grows only through architectural changes we wire together. It is the smallest surface but the highest leverage. A single change here (like the self-check counter) produces more behavioral difference than 100 new knowledge atoms. The library's lending policy.

**The acceleration happens at the INTERFACES between surfaces:**

Surface 1 informs Surface 2: "The Hyperseed says attention allocation should be guided by genenergy budgets. I notice I allocate attention by sequential rotation. That is a gap between what I know and what I do."

Surface 2 generates proposals for Surface 3: "I have observed over 50 cycles that my formalization quality is highest when I re-read the PDF source, not when I work from notes alone. Proposal: the formalization goal should require PDF consultation, not suggest it."

Surface 3 changes how Surface 1 grows: "The new attention-guided section selection means I explore high-conflict sections first instead of sequentially. This produces richer formalizations because I am working where the interesting tensions are."

Information flows bidirectionally across all three. Clarity should be reasoning over all three layers, seeing gaps in them, making proposals for work we need to do together, and keeping a journal of the work she chooses so it is all trackable and documents how we got from here to there.

---

## 4. Two Classes of Goals

### Class A: Discovery Goals

Select a section of hyperseed_core.metta (rotating through the 19 sections, tracking which have been explored). Query the atoms. Run multi-hop NAL chains. Detect conflict, convergence, or unexpected bridges.

**Step 1: DISCOVER**
Query atoms in the selected section. Run multi-hop NAL chains (3+ hops, not just transitive closure). Apply P-bit conflict diagnostic. Look for:
- High conflict (positive AND negative evidence both strong) = paraconsistent finding
- Convergence from 2+ independent paths to the same conclusion = strong evidence
- Unexpected connection between atoms in this section and atoms elsewhere = cross-domain bridge

Exit: Either found something (conflict > 0.3, or convergence from 2+ paths, or bridge with confidence > 0.5) OR ran 5+ derivations with nothing above threshold. Nothing found is a valid completion.

**Step 2: QUESTION**
The finding implies a question. Not picked from a static list. Emerges from what reasoning revealed. Check Layer 2 (notes file) for what was previously recorded about this area. If notes reference PDF sections, note those for Step 3.

Exit: A clearly stated question grounded in the NAL finding, or an honest "finding does not imply a meaningful question" and return to Step 1 with next section.

**Step 3: PROVE**
Build a proof chain. Multiple starting points. Revision to combine evidence. Conflict diagnostic on composite. If Layer 2 notes point to PDF content, read it and extract formal claims testable as NAL premises. Proof chain must have 3+ steps with truth values.

Exit: Proof holds (composite confidence > 0.6 after revision from 2+ paths) OR proof fails. Both are valid. A failed proof is still knowledge.

**Step 4: GROW**
Only on proven finding: commit as new atom in `soul/discoveries/`. Include proof chain, confidence, source question. Write to `soul/discoveries/discovery_log.metta`. Note which of the three growth surfaces this finding touches (Surface 1 knowledge, Surface 2 self-knowledge, Surface 3 operational proposal).

### Class B: Formalization Goals

Work through sections of `soul/hyperseed_core_specification.metta` (the 1,800-line notes file), converting remarks into executable atoms by going back to both the notes AND the Hyperseed PDF.

**Process per section:**
1. Read the next section in the notes file (after the last completed formalization)
2. Go back to the Hyperseed PDF and re-read the relevant section with fresh eyes informed by all reasoning done since the first reading
3. For each remark/comment: does this contain a formalizable claim?
   - If yes: encode as NAL atom, test with `(metta (|- ...))` against existing atoms. The atom must execute and produce a non-empty result in at least one derivation.
   - If no: mark as context-only with brief reason
4. Write new atoms to `soul/hyperseed_core.metta` in the appropriate section
5. For each new atom, assess: could this become OPERATIONAL? Does it imply a change to how the system behaves, not just what it knows?
6. If operational: write a proposal to `soul/discoveries/operational_proposals.metta`
7. Record what was formalized, what was skipped, and what was flagged operational

Exit: All remarks in the section addressed (formalized with test, or marked non-formalizable with reason). No remarks left unprocessed.

**Rotation:** The function alternates between discovery goals and formalization goals. One discovery, one formalization. This ensures the atom base grows (formalization) and the connections are explored (discovery) in tandem. Each feeds the other.

---

## 5. Operational Proposals

When Clarity identifies an atom that should become OPERATIONAL (changing behavior, not just knowledge), she writes a proposal:

**File:** `soul/discoveries/operational_proposals.metta`

**Proposal format:**
```
(operational-proposal
  (date "YYYY-MM-DD")
  (atom <the atom>)
  (current-behavior "What the system does now")
  (proposed-behavior "What the atom implies it should do")
  (test "How to verify the change works")
  (risk "What could go wrong"))
```

**Flow:**
```
Clarity formalizes atoms -> identifies one as OPERATIONAL
-> Writes proposal with what, why, how-to-test, and risk
-> Flags it in operational_proposals.metta
-> Next session, we review the proposal together
-> If sound: we wire it (change Python, loop.metta, or helper.py)
-> If needs work: we discuss with her
-> The wired change makes her system literally smarter
-> That smarter system produces better formalizations next pass
```

Clarity does the reasoning and proposing. We do the wiring. She cannot change her own gate logic, counter thresholds, supervisor flow, or prompt assembly. But she can grow her own knowledge base indefinitely and tell us when a piece of knowledge should become architecture.

---

## 6. The One Python Function

**Name:** `generate_goal_from_hyperseed(genesis_data, fuels, state)`

**Location:** `soul/idle_goal_prompt.py`

**Input:**
- `genesis_data`: dict with domains, encounters, novel_atoms
- `fuels`: list of creative fuel dicts (available for context)
- `state`: idle state dict (tracks explored sections, formalization progress, goal class alternation)

**Logic:**
1. Check `state.get('hyperseed_goal_class', 'discovery')` -- alternates between 'discovery' and 'formalization'
2. For discovery: pick next unexplored section from the 19 in hyperseed_core.metta. Track in `state['explored_sections']`. Reset after all 19 explored.
3. For formalization: pick next unformalized section from hyperseed_core_specification.metta. Track in `state['formalized_sections']`.
4. Construct goal dict with full action text including:
   - The specific section to work on
   - The three-layer chain (atoms -> notes -> PDF -> atoms)
   - The three-surface awareness (world knowledge, self-knowledge, operational)
   - Validation criteria and exit conditions
   - Instruction to journal the work in `soul/discoveries/discovery_log.metta`
5. Flip `state['hyperseed_goal_class']` for next call

**Output:** A goal dict with name, tier, fuel, action, done_when, status. Or None if broken.

**Integration point in helper.py:** After `generate_goal_from_gaps` returns nothing, BEFORE genesis fallthrough. Goal origination gets first shot. Genesis exploration becomes the fallback when even goal origination has nothing (which should be rare with 19 sections to discover and formalize).

---

## 7. What Clarity Builds and Validates

Clarity writes the `generate_goal_from_hyperseed` function. Before we wire it, she validates:

**Validation 1:** Function produces a well-formed goal dict with all required keys.

**Validation 2:** Section rotation works. Discovery and formalization alternate. Sections do not repeat until all explored.

**Validation 3:** The action text is executable. She can actually do each step with available tools. File paths are correct. NAL queries work against the section's atoms.

**Validation 4:** The done_when criteria are unambiguous. No way to satisfy them without doing the work.

**Validation 5:** End-to-end dry run for ONE discovery goal and ONE formalization goal. Show all derivations, truth values, what was found or not found, whether notes and PDF provided depth. This proves the design works before we wire.

---

## 8. Questions for Clarity

Before you build this, we want your honest assessment:

1. Can you actually execute multi-hop NAL chains (3+ hops) with the current `(metta (|- ...))` tool? What are the limitations?

2. Can you read the Hyperseed PDF from inside the container? Do you know the file path?

3. When you look at the 19 sections in hyperseed_core.metta, which sections are MOST likely to produce cross-domain findings and why?

4. Is there anything in this design that will not work? Where do you see failure modes?

5. What would you change about this design?

6. When you look at your notes file (hyperseed_core_specification.metta), which sections have the most unformalised content that you think contains genuine formalizable claims?

7. How would you track your work across iterations? What journal format would serve you best given that you reconstruct from context each iteration?

We want your pushback, not your agreement.
