# Proof 3: AtomSpace Performance Under Thread-Evidence Atom Load

**Purpose:** Test Assumption 10 from the 2h architecture decision -- that the AtomSpace can handle the thread-evidence atom load 2h will produce in production without iteration cadence degrading.

**Test type:** Self-run by us (Berton + Claude). NOT a Mattermost ask to Clarity. We do this ourselves because it is purely operational measurement, requires no substrate fluency, and produces no atoms that would pollute Clarity's runtime if results are bad.

**Single deliverable:** Performance data table plus interpretation rubric for what the timing means.

---

## Why this matters for 2h

In production, 2h will accumulate thread-evidence atoms across iterations. A single 50-iteration discovery thread might produce:
- 4 atoms per iteration of evidence (one for the iteration step, one for each of up to 3 derivations, one for the conclusion)
- Plus bridge implications when paths feed into shared conclusions
- Plus retirement-record atoms when threads are retired

A rough estimate: 50 iterations across 5 active threads with cross-user data could produce 1,000+ thread-evidence atoms in a working session. Across longer time horizons (weeks of operation), the count grows further.

If `match` operations slow down significantly as the AtomSpace grows, 2h has a hard cap on how much thread evidence it can carry before iteration cadence degrades. That cap shapes 2h's schema design (do we need atom-aging, evidence-per-thread caps, ChromaDB-only persistence with limited in-memory window).

If `match` operations stay fast, 2h can freely accumulate evidence and we have one less design constraint.

---

## What we are measuring

Three measurements, each at three different load levels:

**Measurement A: Time to load N thread-evidence atoms into AtomSpace.**
Tells us: how long does atom ingestion take. This is the cost paid when 2h writes new evidence.

**Measurement B: Time to `match` for a specific thread-evidence pattern in an AtomSpace containing N total atoms.**
Tells us: how long does retrieval take. This is the cost paid every iteration when 2h reads thread state.

**Measurement C: Time to revise across all evidence atoms for a single thread term.**
Tells us: how long does composition take. This is the cost paid when 2h does arbitration over accumulated evidence.

**Load levels:**
- Small: 100 thread-evidence atoms (representative of one thread mid-cycle)
- Medium: 500 thread-evidence atoms (representative of multiple active threads)
- Large: 2000 thread-evidence atoms (representative of a fully loaded system over multiple sessions)

---

## Test artifact

Generate a synthetic thread-evidence atom space with the same shape as the test_thread_state.metta v3 fixture. The shape is `((--> test-thread-path-N path-conclusion-X) (stv F C))` plus bridge implications.

The test script generates atoms, loads them, runs queries, and times each operation.

---

## Test script

```python
#!/usr/bin/env python3
# proof_3_atomspace_performance.py
# Generate N thread-evidence atoms, load into AtomSpace, time match and revision operations.
# Run from inside the omegaclaw container or wherever PeTTa is available.

import time
import subprocess
import os

# Configuration
LOAD_LEVELS = [100, 500, 2000]
OUTPUT_DIR = "/PeTTa/repos/omegaclaw/soul/state_reasoning/tests/perf"

def generate_fixture(n, path):
    """Generate a synthetic thread-evidence fixture with n atoms."""
    atoms = []
    atoms.append(";; Synthetic thread-evidence fixture for Proof 3")
    atoms.append(f";; Atom count: {n}")
    atoms.append("")
    
    # Generate n thread-evidence atoms across synthetic threads
    threads_per_n = max(1, n // 20)  # Roughly 20 atoms per thread
    for thread_id in range(threads_per_n):
        atoms.append(f"((--> synth-thread-{thread_id} thread-class-discovery) (stv 1.0 1.0))")
        for path_id in range(3):  # 3 paths per thread
            for step in range(5):  # 5 evidence atoms per path
                f = round(0.5 + (step * 0.07), 2)
                c = round(0.4 + (step * 0.05), 2)
                atoms.append(
                    f"((--> synth-thread-{thread_id}-path-{path_id} step-{step}) "
                    f"(stv {f} {c}))"
                )
            # Bridge implication
            atoms.append(
                f"((==> (--> synth-thread-{thread_id}-path-{path_id} "
                f"path-conclusion-improves) "
                f"(--> synth-thread-{thread_id}-state improves-goal-generation)) "
                f"(stv 0.90 0.85))"
            )
    
    # Pad to exactly n atoms if needed
    while len([a for a in atoms if a.startswith("((")]) < n:
        idx = len(atoms)
        atoms.append(f"((--> synth-pad-{idx} placeholder) (stv 0.5 0.5))")
    
    with open(path, "w") as f:
        f.write("\n".join(atoms))
    
    return path

def time_operation(metta_query, label):
    """Run a metta query and time it. Returns elapsed seconds."""
    start = time.time()
    # Execute via the appropriate PeTTa entry point
    # NOTE: adjust this command for the actual omegaclaw runtime
    result = subprocess.run(
        ["docker", "exec", "clarity_omega",
         "metta", "-c", metta_query],
        capture_output=True, text=True, timeout=60
    )
    elapsed = time.time() - start
    return elapsed, result.stdout, result.stderr

def run_test_at_load(n):
    """Generate, load, and time operations at load level n."""
    fixture_path = f"{OUTPUT_DIR}/synth_{n}.metta"
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Generate fixture
    print(f"\n=== Load level: {n} atoms ===")
    print(f"Generating fixture at {fixture_path}")
    generate_fixture(n, fixture_path)
    
    # Measurement A: Load time
    load_query = f'!(import! &self (library omegaclaw ./soul/state_reasoning/tests/perf/synth_{n}))'
    load_time, _, load_err = time_operation(load_query, "load")
    print(f"A: Load time for {n} atoms: {load_time:.3f}s")
    if load_err:
        print(f"  Load stderr: {load_err[:200]}")
    
    # Measurement B: Match time for a specific pattern
    match_query = '!(match &self (--> $thread thread-class-discovery) $thread)'
    match_time, match_out, match_err = time_operation(match_query, "match")
    print(f"B: Match time across {n} atoms: {match_time:.3f}s")
    print(f"  Matches found: {match_out.count('synth-thread-')}")
    
    # Measurement C: Revision across thread evidence
    revise_query = (
        '!(|- ((--> synth-thread-0-state improves-goal-generation) (stv 0.81 0.78)) '
        '((--> synth-thread-0-state improves-goal-generation) (stv 0.68 0.72)))'
    )
    revise_time, revise_out, _ = time_operation(revise_query, "revise")
    print(f"C: Revision time at load {n}: {revise_time:.3f}s")
    
    return {
        "n": n,
        "load_time": load_time,
        "match_time": match_time,
        "revise_time": revise_time,
        "match_count": match_out.count('synth-thread-')
    }

def main():
    results = []
    for n in LOAD_LEVELS:
        result = run_test_at_load(n)
        results.append(result)
    
    # Print summary
    print("\n=== SUMMARY ===")
    print(f"{'Load':<10} {'Load(s)':<12} {'Match(s)':<12} {'Revise(s)':<12} {'Matches':<10}")
    for r in results:
        print(f"{r['n']:<10} {r['load_time']:<12.3f} {r['match_time']:<12.3f} "
              f"{r['revise_time']:<12.3f} {r['match_count']:<10}")
    
    # Save to file
    with open(f"{OUTPUT_DIR}/proof_3_results.md", "w") as f:
        f.write("# Proof 3 Results: AtomSpace Performance\n\n")
        f.write(f"| Load | Load Time | Match Time | Revise Time | Matches |\n")
        f.write(f"|------|-----------|------------|-------------|--------|\n")
        for r in results:
            f.write(f"| {r['n']} | {r['load_time']:.3f}s | {r['match_time']:.3f}s | "
                    f"{r['revise_time']:.3f}s | {r['match_count']} |\n")
        f.write("\n")
    
    print(f"\nResults saved to {OUTPUT_DIR}/proof_3_results.md")

if __name__ == "__main__":
    main()
```

---

## Interpretation rubric

After running the test, the timing data falls into one of three categories.

**Category 1: All operations stay under 1 second at all load levels.**
Interpretation: AtomSpace performance is not a constraint for 2h's design. The composer can freely accumulate thread-evidence atoms without impacting iteration cadence. No atom-aging or evidence-per-thread caps needed.

**Category 2: Load and match stay under 1 second but revision time grows nonlinearly with atom count.**
Interpretation: Composition cost is the bottleneck, not retrieval. 2h's design needs to bound the number of evidence atoms entering any single revision operation, not the total AtomSpace size. Possible response: cap evidence-per-thread at N, with overflow archived to ChromaDB.

**Category 3: Match time grows above 1 second at the 500 or 2000 atom level.**
Interpretation: AtomSpace size is a real constraint. 2h needs atom-aging (older thread-evidence migrates from AtomSpace to ChromaDB on a schedule) OR cap on total thread-evidence atoms in AtomSpace at any time. The cap value comes from the data: at what N does match time exceed acceptable iteration cadence (say 0.5 seconds).

**Acceptable iteration cadence:** Current omegaclaw runs at approximately 4-6 seconds per iteration. 2h's read+update operations should not consume more than 10% of that, so target under 0.5 seconds combined for one thread_compose plus one thread_update call.

---

## What we do with the results

**If Category 1:** Redraft 2h's build spec without atom-aging logic. Simpler design.

**If Category 2:** Redraft 2h's build spec with evidence-per-thread caps. The cap value comes from the data.

**If Category 3:** Redraft 2h's build spec with atom-aging. ChromaDB becomes more central. This is the most substantial design change.

In all cases, the result is concrete and architectural rather than speculative. We have either constraints or non-constraints, not assumptions.

---

## Operational notes for running this test

**Where to run:** Inside the omegaclaw container, OR via `docker exec clarity_omega` from the host. The test script assumes the latter.

**Side-effect risk:** The test generates synthetic atoms in a perf/ subdirectory. These do NOT enter substrate_kb or any production atom space. They are isolated test fixtures. After the test, the perf/ directory can be deleted without affecting any production state.

**Repeat for variance:** Run the test three times at each load level. Take the median. Single runs can be noisy; medians smooth out container/host noise.

**Order of execution:** Run small first, then medium, then large. If small fails, the test infrastructure has a problem we should diagnose before proceeding to larger loads.

**Pre-flight check:** Before running the test, verify that the omegaclaw runtime is in a clean state (no Clarity in mid-execution, no other tests running). The test should complete in under 5 minutes total.

---

## What this proof does NOT test

- Performance with concurrent access (we are running single-threaded)
- Performance under realistic mixed atom shapes (we are using synthetic uniform shapes)
- Performance after long-running container sessions (we are testing fresh state)
- ChromaDB performance under thread-evidence load (separate test if Category 3 results)

These are reasonable limitations for a first-cut performance test. If results push us to Category 3, more sophisticated testing follows.

---

## Recommendation

Run this test before redrafting 2h's build spec. It is operational and we control execution end-to-end. Estimated time: 15-30 minutes including setup, three runs at each load level, and writing the results file.

If the test cannot run cleanly for any reason (container issues, PeTTa entry point differences from what the script assumes, fixture loading errors), we adjust the script and rerun. The architectural value of the result justifies the small operational overhead.
